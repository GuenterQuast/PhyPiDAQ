"""Definition for the AllWinner H3 chip"""
