"""Definition for the AllWinner H616 chip"""
