"""Definition for the AllWinner H6 chip"""
