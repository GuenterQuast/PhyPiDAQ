"""Boards definition from STM32"""
