"""Boards definition from Banana Pi"""
