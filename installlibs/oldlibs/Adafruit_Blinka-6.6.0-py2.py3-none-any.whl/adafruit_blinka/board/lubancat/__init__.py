"""Boards definition from LubanCat"""
