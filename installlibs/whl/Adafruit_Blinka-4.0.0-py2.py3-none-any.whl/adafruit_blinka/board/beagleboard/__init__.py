"""Boards definition from BeagleBoard"""
